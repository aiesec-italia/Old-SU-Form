require.config({
baseUrl: "",
paths: {
    "js": ""
},
});
