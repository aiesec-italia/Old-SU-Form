 require( ["js/control"
        ,"js/clases/ajax"
        ,"js/clases/constantes"],
    function(control,ajax,constantes) {
        var JsonUniversidades;
    	var Validar=function(){
    		var txtFirstName=$("#txtFirstName");
    		var txtLastName=$("#txtLastName");
			var txtAge=$("#txtAge");
    		var txtPhone=$("#txtPhone");
    		var txtmail=$("#txtmail");
    		var lstUniversidad=$("#lstUniversidad");
    		var txtPassword=$("#txtPassword");
    		var txtSecondPassword=$("#txtSecondPassword");
    		var lstConocioOrganizacion=$("#lstConocioOrganizacion");
            

    		if(txtFirstName.val()==""){
    			swal(" Scrivi il tuo nome");
    			return false;
    		}else if(txtLastName.val()==""){
    			swal("Scivi il tuo cognome");
    			return false;
    		}else if(txtAge.val()==""){
    			swal("Scivi il tuo età");
    			return false;
    		} 
    		else if(txtPhone.val()==""){
    			swal("Scrivi il tuo numero di telefono");
    			return false;
    		} 
    		else if(txtmail.val()==""){
    			swal("Scrivi la tua mail");
    			return false;
    		} 
    		else if(lstUniversidad.val()==null){
    			swal("Scrivi quale università frequent?");
    			return false;
    		}
			else if(txtPassword.val()==""){
    			swal("Crea la tua password");
    			return false;
    		} 
    		else if(txtSecondPassword.val()==""){
    			swal("Ripeti la password");
    			return false;
    		} 
    		else if(lstConocioOrganizacion.val()==null){
    			swal("Seleziona da dove hai sentito parlare di AIESEC");
    			return false;
    		} else if(txtPassword.val()!=txtSecondPassword.val()){
    			swal("Le password non corrispondono");
    			return false;
    		}
            else if(!($("#rbAceptoTerminos").is(":checked"))){
                swal("Acconsenti ai termini e alle condizioni di utilizzo");
            }
            else if(!($("#rbAceptoTerminos2").is(":checked"))){
                swal("Secondo la GDPR valida dal 25 maggio 2018, sei consapevole dei modi di protezione dei dati personali e accetti i termini e le condizioni di segretezza");
            }
            else{
    			return true;
    		}

    	}

        var saveEndAjax=function(data){
            window.open("https://www.aiesec.it/thank-you-gv");
            swal({
              title: "La registrazione è andata a buon fine!",
              text: " ",
              type: "success",
              showCancelButton: false,
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "Accetta",
              closeOnConfirm: false
            },
            function(){
               location.reload();
            });

        }

        var endLoadList=function(data){
            JsonUniversidades=data.alignments;
            $.each(data.alignments,function(index,value){
                $("#lstUniversidad").append('<option value="'+value.id+'">'+value.value+'</option>');
            });
            var list=$(".listas");
            control.loadList(list);
        }
        var ValidarClave=function(text){
        var pswd = text;
            //validate the length
            if ( pswd.length < 8 ) {
               swal("La password deve contenere almeno 8 caratteri");
               return false;
            }
            else if ( pswd.match(/[A-Z]/g) == null)  {
                swal("La password deve contenere almeno una lettera maiuscola");
                return false;
            }else if ( pswd.match(/[a-z]/g) == null)  {
                swal("La password deve contenere almeno una lettera minuscola");
                return false;
            }else if ( pswd.match(/\d/) == null)  {
                swal("La password deve contenere almeno un numero");
                return false;
            }else{
                return true;
            }
       };
    	var start=function(){
            $.each(constantes.actividades(),function(index, value){
                    $("#lstCampos").append('<option value="'+value.name+'">'+value.name+'</option>');

                });
    		$("#btnIngresar").click(function(){
                var universidadNombre;
                lstU= document.getElementById("lstUniversidad");
                universidadNombre=lstU.options[lstU.selectedIndex].innerHTML;
                
    			if(Validar() && ValidarClave($("#txtPassword").val())){
                    var url="index.php?r=voluntarioGlobal/InserExpa";
                    var data={};                   
                    data["txtFirstName"]=$("#txtFirstName").val();
                    data["txtLastName"]=$("#txtLastName").val();
					data["txtAge"]=$("#txtAge").val();
                    data["txtPhone"]=$("#txtPhone").val();
                     
                    data["txtmail"]=$("#txtmail").val();
                    data["valUniversidad"]=$("#lstUniversidad").val();
                    data["nombreUniversidad"]=universidadNombre;
                    data["txtPassword"]=$("#txtPassword").val();
                    data["txtSecondPassword"]=$("#txtSecondPassword").val();
                    data["lstConocioOrganizacion"]=$("#lstConocioOrganizacion").val();
                   
                    
    				ajax.ajaxSinJson(data,url,saveEndAjax,errorEnd);
                    $.blockUI({ 
                        message: $(' <div class="progress"><div class="indeterminate"></div></div>'), 
                        css: { top: '20%' } 
                    }); 
                }
    		});
            $("#btnTerminosCondiciones").click(function(e){
                e.preventDefault();
                window.open("https://opportunities.aiesec.org/assets/terms.pdf");
            });
            $("#btnTerminosCondiciones2").click(function(e){
                e.preventDefault();
                window.open("https://aiesec.gr/wp-content/uploads/2018/06/B4.pdf");
            });
            ajax.ajax({},"index.php?r=voluntarioGlobal/UniversitiesGreece",endLoadList);


    	};

        var errorEnd=function(error){
            console.log(error);
        }

        $(document).ready(start);
    }
  );