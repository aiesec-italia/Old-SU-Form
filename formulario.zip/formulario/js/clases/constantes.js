define([]
    , function ( ) {
        return {
            actividades:function(){
                var l=[
                          {
                            "id": 742,
                            "name": "Training"
                          },
                          {
                            "id": 715,
                            "name": "Accounting / Auditing"
                          },
                          {
                            "id": 716,
                            "name": "Advertising"
                          },
                          {
                            "id": 717,
                            "name": "Analyst"
                          },
                          {
                            "id": 718,
                            "name": "Art / Creative"
                          },
                          {
                            "id": 719,
                            "name": "Business Development"
                          },
                          {
                            "id": 720,
                            "name": "Consulting"
                          },
                          {
                            "id": 721,
                            "name": "Customer Service"
                          },
                          {
                            "id": 722,
                            "name": "Design"
                          },
                          {
                            "id": 723,
                            "name": "Education"
                          },
                          {
                            "id": 724,
                            "name": "Engineering"
                          },
                          {
                            "id": 725,
                            "name": "Finance"
                          },
                          {
                            "id": 726,
                            "name": "Human Resources"
                          },
                          {
                            "id": 727,
                            "name": "Information Technology"
                          },
                          {
                            "id": 728,
                            "name": "Legal"
                          },
                          {
                            "id": 729,
                            "name": "Management"
                          },
                          {
                            "id": 730,
                            "name": "Marketing"
                          },
                          {
                            "id": 731,
                            "name": "Other"
                          },
                          {
                            "id": 732,
                            "name": "Public Relations"
                          },
                          {
                            "id": 733,
                            "name": "Purchasing"
                          },
                          {
                            "id": 734,
                            "name": "Product Management"
                          },
                          {
                            "id": 735,
                            "name": "Project Management"
                          },
                          {
                            "id": 736,
                            "name": "Production"
                          },
                          {
                            "id": 737,
                            "name": "Quality Assurance"
                          },
                          {
                            "id": 738,
                            "name": "Research"
                          },
                          {
                            "id": 739,
                            "name": "Sales"
                          },
                          {
                            "id": 740,
                            "name": "Strategy / Planning"
                          },
                          {
                            "id": 741,
                            "name": "Supply Chain"
                          },
                          {
                            "id": 743,
                            "name": "Writing / Editing"
                          }
                        ];
                return l;
            }
        };
    });