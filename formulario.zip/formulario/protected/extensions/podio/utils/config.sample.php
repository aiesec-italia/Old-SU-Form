<?php

define("CLIENT_ID", "");
define("CLIENT_SECRET", "");
define("APP_ID", "");
define("APP_TOKEN", "");

define('FIELD_ID', 0);

// Make sure errors are output to the screen
ini_set('display_errors', '1');
