<?php 
	 class Comite{
		

		public function getValorPodio($idComite){
			 $lstComites=array(
				865 => array('Comite' => "Bari", 'ValorPodio'=> 2),
				96 => array('Comite' => "BOLOGNA", 'ValorPodio'=> 3),
				1641 => array('Comite' => "Brescia", 'ValorPodio'=> 4),
				878 => array('Comite' => "CATANIA", 'ValorPodio'=> 5),
				2079 => array('Comite' => "Enna", 'ValorPodio'=> 6),
				95 => array('Comite' => "FERRABA", 'ValorPodio'=> 7),
				2038 => array('Comite' => "Firenze", 'ValorPodio'=> 8),
				1453 => array('Comite' => "GENOVA", 'ValorPodio'=> 9),
				930 => array('Comite' => "Milano", 'ValorPodio'=> 10),
				2081 => array('Comite' => "Milano UniMi", 'ValorPodio'=> 11),
				2338 => array('Comite' => "Modena", 'ValorPodio'=> 12),
				1035 => array('Comite' => "NAPOLI FEDERICO II", 'ValorPodio'=> 13),
				1120 => array('Comite' => "NAPOLI PARTHENOPE", 'ValorPodio'=> 14),
				83 => array('Comite' => "PADOVA", 'ValorPodio'=> 15),
				1069 => array('Comite' => "PALERMO", 'ValorPodio'=> 16),
				2080 => array('Comite' => "Parma", 'ValorPodio'=> 17),
				1117 => array('Comite' => "PAVIA", 'ValorPodio'=> 18),
				2326 => array('Comite' => "Perugia", 'ValorPodio'=> 19),
				2325 => array('Comite' => "Pescara", 'ValorPodio'=> 20),
				754 => array('Comite' => "ROMA SAPIENZA", 'ValorPodio'=> 21),
				2037 => array('Comite' => "Roma Tor Vergata", 'ValorPodio'=> 22),
				821 => array('Comite' => "ROMA TRE", 'ValorPodio'=> 23),
				2028 => array('Comite' => "Siena", 'ValorPodio'=> 24),
				1004 => array('Comite' => "TORINO", 'ValorPodio'=> 25),
				2322 => array('Comite' => "PoliTO", 'ValorPodio'=> 26),
				1370 => array('Comite' => "TRENTO", 'ValorPodio'=> 27),
				689 => array('Comite' => "TRIESTE", 'ValorPodio'=> 28),
				842 => array('Comite' => "Udine", 'ValorPodio'=> 29),
				1648 => array('Comite' => "Urbino", 'ValorPodio'=> 30),
				1389 => array('Comite' => "VENEZIA", 'ValorPodio'=> 32),
				425 => array('Comite' => "VERONA", 'ValorPodio'=> 33),
				);

			return $lstComites[$idComite]["ValorPodio"];
		}
	}
 ?>