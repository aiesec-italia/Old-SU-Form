<?php 
	 class Comite{
		

		public function getValorPodio($idComite){

			 $lstComites=array(
				//mapping ok
				865 => array('Comite' => "Bari", 'ValorPodio'=> 2),
				96 => array('Comite' => "BOLOGNA", 'ValorPodio'=> 3),
				1641 => array('Comite' => "Brescia", 'ValorPodio'=> 4),
				878 => array('Comite' => "CATANIA", 'ValorPodio'=> 5),
				2079 => array('Comite' => "Enna", 'ValorPodio'=> 6),
				95 => array('Comite' => "FERRABA", 'ValorPodio'=> 7),
				2038 => array('Comite' => "Firenze", 'ValorPodio'=> 8),
				1453 => array('Comite' => "GENOVA", 'ValorPodio'=> 9),
				930 => array('Comite' => "Milano", 'ValorPodio'=> 11),				

				//mapping updated
				2338 => array('Comite' => "Modena", 'ValorPodio'=> 13),
				1035 => array('Comite' => "NAPOLI FEDERICO II", 'ValorPodio'=> 14),
				1120 => array('Comite' => "NAPOLI PARTHENOPE", 'ValorPodio'=> 15),
				83 => array('Comite' => "PADOVA", 'ValorPodio'=> 16),
				1069 => array('Comite' => "PALERMO", 'ValorPodio'=> 17),
				2080 => array('Comite' => "Parma", 'ValorPodio'=> 18),
				1117 => array('Comite' => "PAVIA", 'ValorPodio'=> 19),
				2326 => array('Comite' => "Perugia", 'ValorPodio'=> 20),
				2325 => array('Comite' => "Pescara", 'ValorPodio'=> 21),
				754 => array('Comite' => "ROMA SAPIENZA", 'ValorPodio'=> 22),
				2037 => array('Comite' => "Roma Tor Vergata", 'ValorPodio'=> 23),
				821 => array('Comite' => "ROMA TRE", 'ValorPodio'=> 24),
				2028 => array('Comite' => "Siena", 'ValorPodio'=> 25),
				1004 => array('Comite' => "TORINO", 'ValorPodio'=> 26),
				2322 => array('Comite' => "PoliTO", 'ValorPodio'=> 27),
				1370 => array('Comite' => "TRENTO", 'ValorPodio'=> 28),
				689 => array('Comite' => "TRIESTE", 'ValorPodio'=> 29),
				842 => array('Comite' => "Udine", 'ValorPodio'=> 30),
				1648 => array('Comite' => "Urbino", 'ValorPodio'=> 31),
				
				//mapping ok
				1389 => array('Comite' => "VENEZIA", 'ValorPodio'=> 32),
				425 => array('Comite' => "VERONA", 'ValorPodio'=> 33),

				//missing
				2335 => array('Comite' => "Cagliari", 'ValorPodio'=> 35),
				1793 => array('Comite' => "Lecce", 'ValorPodio'=> 36),				
			);

			return $lstComites[$idComite]["ValorPodio"];
		}
	}
 ?>