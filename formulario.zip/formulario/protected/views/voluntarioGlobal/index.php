<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>

    <style type="text/css">
      @font-face { font-family: "Lato-Light";
                src: url('assets/Lato-Light.ttf');
                 }
      html{
        font-family: "Lato-Light";
        background-color: white;
      }
      body{
        background-color: white;
      }
    </style>
  </head>
  <body>
  <div class="container">
  <form action="{path-gis_reg_process}" method="POST" class="regform" id="expa_reg_form" accept-charset="UTF-8" 
          style="background-color: transparent; width:80%; margin-left:10%;" onsubmit="boton.disabled = true; return true;">
      <div class="col s12 m12">
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">account_circle</i>
         <input id="txtFirstName" type="text" class="validate">
         <label for="txtFirstName">Nome*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">perm_identity</i>
         <input id="txtLastName" type="text" class="validate">
         <label for="txtLastName">Cognome*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">perm_identity</i>
         <input id="txtAge" type="text" class="validate">
         <label for="txtAge">Età*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">phone</i>
         <input id="txtPhone" type="text" class="validate">
         <label for="txtPhone">Telefono *</label>
      </div>
       
      <div class="input-field col s12">
        <i class="material-icons prefix">email</i>
        <input id="txtmail" type="email" class="validate">
        <label for="email">Email*</label> 
      </div>
      <!--region-->
      <div class="input-field col s12">
        <i class="material-icons prefix" >map</i>
         <select class="listas" id="lstRegion">
           <option value="" disabled selected>Scegli la tua regione</option>
           <?php 
            foreach($regions as $region){
              echo '<option value="' . $region['name'] . '" >' . $region['name'] . '</option>';
            }
          ?>
         </select>
         <label>Regione</label>
     </div>     

      <!--city-->
      <div class="input-field col s12">
        <i class="material-icons prefix" >house</i>
         <select class="listas" id="lstCity">
          <option value="" disabled selected>Scegli la tua città</option>
         </select>
         <label>Città</label>
      </div>

      <!--university-->
      <div class="input-field col s12">
        <i class="material-icons prefix" >local_library</i>
         <select class="listas" id="lstUniversidad">
          <option value="" disabled selected>Scegli l'università in cui studi o hai studiato</option>
         </select>
         <label>Università*</label>
     </div>
     
     <div class="input-field col s12">
        <i class="material-icons prefix">vpn_key</i>
        <input id="txtPassword" type="password" class="validate">
        <label for="txtPassword">Password*</label>          
      </div>
      <div><label>La password deve contenere<a> almeno otto caratteri, di cui un numero, una lettera maiuscola e una lettera minuscola.</a></label></div>
      <div class="input-field col s12">
        <i class="material-icons prefix">vpn_key</i>
        <input id="txtSecondPassword" type="password" class="validate">
        <label for="txtSecondPassword">Ripeti la password*</label>
      </div>
      <div class="input-field col s12">
        <i class="material-icons prefix">record_voice_over</i>
         <select class="listas" id="lstConocioOrganizacion">
           <option value="" disabled selected>Da dove hai sentito parlare di AIESEC?</option>
           <option value="10">Facebook</option>
           <option value="11">Instagram</option>
           <option value="12">Email</option>
           <option value="13">Presentazione in classe</option>
           <option value="14">Volantini/locandine</option>
           <option value="15">Eventi</option>
           <option value="16">Banchetto informativo</option>
           <option value="17">Università/professori</option>
           <option value="18">Amici</option>
           <option value="19">Sito</option>
           <option value="20">Articoli web</option>
           <option value="21">Altro</option>
         </select>
         <label>Da dove hai sentito parlare di AIESEC?*</label>
     </div>
     
     <div class="input-field col s12">
        <input type="checkbox" id="rbAceptoTerminos" />
        <label for="rbAceptoTerminos">Acconsento <a id="btnTerminosCondiciones"> al trattamento dei miei dati</a></label>
     </div>
     <div class="input-field col s12">          
        <input type="checkbox" id="rbAceptoTerminos2" />
        <label for="rbAceptoTerminos2">Sono consapevole  <a id="btnTerminosCondiciones2">dei miei diritti sui miei dati personali e di come vengono gestiti dall'organizzazione, e acconsento al processamento. </label>
     </div>

    <div class="input-field col s12">
        <br></br>
        <br></br>
    <a class="waves-effect waves-light btn" id=btnIngresar style="background-color: '#f85a40'">Registrati</a>
    </div>
    </form>
  </div>
     <style type="text/css">
      @font-face { font-family: "Lato-Light";
                src: url('<?php echo Yii::app()->request->baseUrl; ?>/assets/Lato-Light.ttf');
                 }
      html,body{
        font-family: "Lato-Light";
        color: #5d5d5d;
      }
      #btnIngresar{
        background-color: #f85a40; 
      }
      #title{
        color: #f85a40; 
      }
      .material-icons{
        color: #f85a40; 
      }
    </style>
   <script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/js/voluntarioGlobal.js"></script>
  </body>
</html>