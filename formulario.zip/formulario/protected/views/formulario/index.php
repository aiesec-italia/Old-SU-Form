<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>

    <style type="text/css">
      @font-face { font-family: "Lato-Light";
                src: url('assets/Lato-Light.ttf');
                 }
      html{
        font-family: "Lato-Light";
        background-color: white;
      }
      body{
        background-color: white;
      }
    </style>
  </head>
  <body>
  <div class="container">
   <form action="{path-gis_reg_process}" method="POST" class="regform" id="expa_reg_form" accept-charset="UTF-8" 
          style="background-color: transparent; width:80%; margin-left:10%;" onsubmit="boton.disabled = true; return true;">
      <div class="input-field col s12">
         <i class="material-icons prefix">account_circle</i>
         <input id="txtFirstName" type="text" class="validate">
         <label for="txtFirstName">Nome*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">perm_identity</i>
         <input id="txtLastName" type="text" class="validate">
         <label for="txtLastName">Cognome*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">perm_identity</i>
         <input id="txtAge" type="text" class="validate">
         <label for="txtAge">Età*</label>
      </div>
      <div class="input-field col s12">
         <i class="material-icons prefix">phone</i>
         <input id="txtPhone" type="text" class="validate">
         <label for="txtPhone">Telefono *</label>
      </div>
       
      <div class="input-field col s12">
        <i class="material-icons prefix">email</i>
        <input id="txtmail" type="email" class="validate">
        <label for="email">Email*</label> 
      </div>

      <!--region-->
      <div class="input-field col s12">
        <i class="material-icons prefix" >map</i>
         <select class="listas" id="lstRegion">
           <option value="" disabled selected>Scegli la tua regione</option>
           <?php 
            foreach($regions as $region){
              echo '<option value="' . $region['name'] . '" >' . $region['name'] . '</option>';
            }
          ?>
         </select>
         <label>Regione</label>
     </div>     

      <!--city-->
      <div class="input-field col s12">
        <i class="material-icons prefix" >house</i>
         <select class="listas" id="lstCity">
          <option value="" disabled selected>Scegli la tua città</option>
         </select>
         <label>Città</label>
      </div>
      
      <!--university-->
      <div class="input-field col s12" id="dropdown-menu">
        <i class="material-icons prefix" >local_library</i>
         <select class="listas" id="lstUniversidad">
           <option value="" disabled selected>Scegli l'università in cui studi o hai studiato</option>             
         </select>
         <label>Università*</label>
      </div>

      <div class="input-field col s12">
        <i class="material-icons prefix" >local_library</i>
         <select class="listas" id="lstDepartments">
           <option value="" disabled selected>Scegli la facoltà che frequenti o hai frequentato</option>
           <option value="Accounting & Finance">Accounting & Finance</option>
			<option value="Agriculture">Agriculture</option>
			<option value="Applied Informatics">Applied Informatics</option>
			<option value="Architecture">Architecture</option>
			<option value="Balkan Slavic & Oriental Studies">Balkan Slavic & Oriental Studies</option>
			<option value="Banking & Financial Management">Banking & Financial Management</option>
			<option value="Biological Applications & Technologies">Biological Applications & Technologies</option>
			<option value="Biology">Biology</option>
			<option value="Biotechnology">Biotechnology</option>
			<option value="Business Administration">Business Administration</option>
			<option value="Chemical Engineering">Chemical Engineering</option>
			<option value="Chemistry">Chemistry</option>
			<option value="Civil Engineering">Civil Engineering</option>
			<option value="Communication & Media Studies">Communication & Media Studies</option>
			<option value="Computer Engineering & Informatics">Computer Engineering & Informatics</option>
			<option value="Computer Sciences">Computer Sciences</option>
			<option value="Cultural Heritage Management & New Technologies">Cultural Heritage Management & New Technologies</option>
			<option value="Cultural Technology & Communication">Cultural Technology & Communication</option>
			<option value="Dentistry">Dentistry</option>
			<option value="Digital Systems">Digital Systems</option>
			<option value="Drama">Drama</option>
			<option value="Early Childhood Education">Early Childhood Education</option>
			<option value="Economics">Economics</option>
			<option value="Educational & Social Policy">Educational & Social Policy</option>
			<option value="Educational Sciences & Early Childhood Education">Educational Sciences & Early Childhood Education</option>
			<option value="Electrical & Computer Engineering">Electrical & Computer Engineering</option>
			<option value="English Language & Literature">English Language & Literature</option>
			<option value="Environmental & Natural Resources Management">Environmental & Natural Resources Management</option>
			<option value="Film Studies">Film Studies</option>
			<option value="Financial & Management Engineering">Financial & Management Engineering</option>
			<option value="Food Science & Nutrition">Food Science & Nutrition</option>
			<option value="Forestry & Natural Environment">Forestry & Natural Environment</option>
			<option value="French Language & Literature">French Language & Literature</option>
			<option value="Geography">Geography</option>
			<option value="Geology & Geoenviromment">Geology & Geoenviromment</option>
			<option value="German Language & Literature">German Language & Literature</option>
			<option value="History & Archeology">History & Archeology</option>
			<option value="History & Philosophy of Science">History & Philosophy of Science</option>
			<option value="Industrial Management & Technology">Industrial Management & Technology</option>
			<option value="Informatics & Telecommunications">Informatics & Telecommunications</option>
			<option value="Information & Communication System Engineering">Information & Communication System Engineering</option>
			<option value="International & European Studies">International & European Studies</option>
			<option value="Italian Language & Literature">Italian Language & Literature</option>
			<option value="Journalism & Mass Communications">Journalism & Mass Communications</option>
			<option value="Law">Law</option>
			<option value="Management Science & Technology">Management Science & Technology</option>
			<option value="Marine Sciences">Marine Sciences</option>
			<option value="Marketing & Communication">Marketing & Communication</option>
			<option value="Material Science & Technology">Material Science & Technology</option>
			<option value="Mathematics">Mathematics</option>
			<option value="Mathematics & Applied Mathematics">Mathematics & Applied Mathematics</option>
			<option value="Mechanical Engineering & Aeronautics">Mechanical Engineering & Aeronautics</option>
			<option value="Mechanical Engineering">Mechanical Engineering</option>
			<option value="Medicine">Medicine</option>
			<option value="Mediterranean Studies">Mediterranean Studies</option>
			<option value="Mining & Metallurgical Engineering">Mining & Metallurgical Engineering</option>
			<option value="Music Science & Art">Music Science & Art</option>
			<option value="Naval Architecture & Marine Engineering">Naval Architecture & Marine Engineering</option>
			<option value="Nursing">Nursing</option>
			<option value="Nutrition Science">Nutrition Science</option>
			<option value="Pastoral & Social Theology">Pastoral & Social Theology</option>
			<option value="Pharmacy">Pharmacy</option>
			<option value="Philology">Philology</option>
			<option value="Philosophy">Philosophy</option>
			<option value="Physical Education & Sport Science">Physical Education & Sport Science</option>
			<option value="Physics">Physics</option>
			<option value="Plastic Arts & Art Sciences">Plastic Arts & Art Sciences</option>
			<option value="Political Sciences">Political Sciences</option>
			<option value="Pre-school Education">Pre-school Education</option>
			<option value="Primary School Education">Primary School Education</option>
			<option value="Product & Systems Design Engineering">Product & Systems Design Engineering</option>
			<option value="Psychology">Psychology</option>
			<option value="Rural & Surveying Engineering">Rural & Surveying Engineering</option>
			<option value="Russian Language & Literature, and Slavic Studies">Russian Language & Literature, and Slavic Studies</option>
			<option value="Shipping, Trade, and Transport">Shipping, Trade, and Transport</option>
			<option value="Social Anthropology & History">Social Anthropology & History</option>
			<option value="Social Theology">Social Theology</option>
			<option value="Sociology">Sociology</option>
			<option value="Spacial Planning & Development">Spacial Planning & Development</option>
			<option value="Spanish Language & Literature">Spanish Language & Literature</option>
			<option value="Statistics">Statistics</option>
			<option value="TEI Business Administration">TEI Business Administration</option>
			<option value="TEI Occupational Therapy">TEI Occupational Therapy</option>
			<option value="TEI Social Work">TEI Social Work</option>
			<option value="TEI Tourism Management">TEI Tourism Management</option>
			<option value="Theater Studies">Theater Studies</option>
			<option value="Theology">Theology</option>
			<option value="Tourism Studies">Tourism Studies</option>
			<option value="Turkish Studies & Modern Asian Studies">Turkish Studies & Modern Asian Studies</option>
			<option value="Veterinary Medicine">Veterinary Medicine</option>
			<option value="Visual & Applied Arts">Visual & Applied Arts</option>
         </select>
         <label>Facoltà*</label>
     </div>
    <div class="input-field col s12">
        <i class="material-icons prefix">favorite</i>
         <select class="listas" id="programInterest">
           <option value="" disabled selected>Scegli la tipologia di progetto a cui potresti essere più interessato</option>
           <option value="1">Business Administration</option>
           <option value="2">Marketing</option>
           <option value="3">Engineering</option>
           <option value="4">IT</option>
         </select>
         <label>Programma d'interesse*</label>
     </div>
     <div class="input-field col s12">
        <i class="material-icons prefix">vpn_key</i>
        <input id="txtPassword" type="password" class="validate">
        <label for="txtPassword">Password*</label>          
      </div>
      
      <div><label>La password deve contenere<a> almeno otto caratteri, di cui un numero, una lettera maiuscola e una lettera minuscola.</a></label></div>
      <div class="input-field col s12">
        <i class="material-icons prefix">vpn_key</i>
        <input id="txtSecondPassword" type="password" class="validate">
        <label for="txtSecondPassword">Ripeti la password*</label>

      </div>

      <div class="input-field col s12">
        <i class="material-icons prefix">record_voice_over</i>
         <select class="listas" id="lstConocioOrganizacion">
           <option value="" disabled selected>Da dove hai sentito parlare di AIESEC?</option>
           <option value="10">Facebook</option>
           <option value="11">Instagram</option>
           <option value="12">Email</option>
           <option value="13">Presentazione in classe</option>
           <option value="14">Volantini/locandine</option>
           <option value="15">Eventi</option>
           <option value="16">Banchetto informativo</option>
           <option value="17">Università/professori</option>
           <option value="18">Amici</option>
           <option value="19">Sito</option>
           <option value="20">Articoli web</option>
           <option value="21">Altro</option>
         </select>
         <label>Da dove hai sentito parlare di AIESEC?*</label>
     </div>
      
      
     <div class="input-field col s12">        
        <input type="checkbox" id="rbAceptoTerminos" />
        <label for="rbAceptoTerminos">Acconsento <a id="btnTerminosCondiciones"> al trattamento dei miei dati </a></label>
     </div>
     <div class="input-field col s12">          
        <input type="checkbox" id="rbAceptoTerminos2" />
        <label for="rbAceptoTerminos2">Sono consapevole  <a id="btnTerminosCondiciones2">dei miei diritti sui miei dati personali e di come vengono gestiti dall'organizzazione, e acconsento al processamento. </label>
     </div>

    <div class="input-field col s12">
        <br></br>
    <a class="waves-effect waves-light btn" id=btnIngresar style="background-color: '#30c39e'">Registrati</a>
    </div>
    </form>
  </div>
     <style type="text/css">
      @font-face { font-family: "Lato-Light";
                src: url('<?php echo Yii::app()->request->baseUrl; ?>/assets/Lato-Light.ttf');
                 }
      html,body{
        font-family: "Lato-Light";
        color: #5d5d5d;
      }
      #btnIngresar{
        background-color: #30c39e; 
      }
      #title{
        color: #30c39e; 
      }
      .material-icons{
        color: #30c39e; 
      }
    </style>
   <script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/js/formulario.js"></script>
  </body>
</html>