<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii1.1/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
