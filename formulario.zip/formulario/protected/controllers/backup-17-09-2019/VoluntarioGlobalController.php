
<?php
class VoluntarioGlobalController extends Controller
{
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionIndex()
	{
		// renders the view file 'protected/views/site/index.php'
		// using the default layout 'protected/views/layouts/main.php'
		$this->render('index');
	}

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
		if($error=Yii::app()->errorHandler->error)
		{
			if(Yii::app()->request->isAjaxRequest)
				echo $error['message'];
			else
				$this->render('error', $error);
		}
	}

	public function actionInserExpa(){
		try {
			$Json= $_POST['parametros'];
			$app_id=21917709;
			$app_token="c9444a87922440229188519f8917127a";
			Yii::import("application.extensions.podio.PodioAPI", true);
			Yii::import("application.extensions.Utilidades.Comite", true);
			Podio::setup("developergreece", "79dRsK00aBKgWZDJihd9ytP9L7DkX2yyDEiNqdfjjvrr7h1lV9AMKk55VW1BKTvp");
			Podio::authenticate_with_app($app_id, $app_token);
			$Comite=new Comite();
		

			$fields = new PodioItemFieldCollection(array(
			  new PodioTextItemField(array("external_id" => "titulo", "values" => $Json['txtFirstName'] )),
			  new PodioTextItemField(array("external_id" => "last-name", "values" => $Json['txtLastName'])),
			  new PodioTextItemField(array("external_id" => "age", "values" => $Json['txtAge'])),
			  new PodioTextItemField(array("external_id" => "telephone",  "values" => $Json['txtPhone'])),
			   
			  new PodioCategoryItemField(array("external_id" => "email", "values" => $Json['txtmail'])),
			  new PodioCategoryItemField(array("external_id" => "iduniversity", "values" => $Json['valUniversidad'])),
			  new PodioCategoryItemField(array("external_id" => "university-city", "values" => $Json['nombreUniversidad'])),
			  new PodioCategoryItemField(array("external_id" => "department", "values" => $Json['valDepartment'])),
			  new PodioCategoryItemField(array("external_id" => "lc", "values" => $Comite->getValorPodio((int) $Json['valUniversidad']))),
			  new PodioCategoryItemField(array("external_id" => "how-did-you-hear-about-aiesec-2", "values" => (int) $Json['lstConocioOrganizacion']))
			  
			  ));

			$item = new PodioItem(array(
			  'app' => new PodioApp($app_id), 
			  'fields' => $fields
			  ));

			// Save the new item
			$item->save();
			$idGreece=1542;
			$nameGreece="ITALY";
			$curl = curl_init();
			// Set some options - we are passing in a useragent too here
			curl_setopt_array($curl, array(
			    CURLOPT_RETURNTRANSFER => 1,
			    CURLOPT_URL => 'https://auth.aiesec.org/users/sign_in',
			    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
			    ));		
			$result = curl_exec($curl);		
			curl_close($curl);		
			preg_match('/<meta content="(.*)" name="csrf-token" \/>/', $result, $matches);
			$gis_token = $matches[1];
			
			$fields = array(
		    'authenticity_token' => htmlspecialchars($gis_token),
		    'user[email]' => htmlspecialchars($Json['txtmail']),
		    'user[first_name]' => htmlspecialchars($Json['txtFirstName']),
		    'user[last_name]' => htmlspecialchars($Json['txtLastName']),
		    'user[password]' => htmlspecialchars($Json['txtPassword']),
		    'user[phone]' => htmlspecialchars($Json['txtPhone']),
		    'user[country]' => $nameGreece,  
		    'user[mc]' => $idGreece, 
		    'user[lc_input]' => htmlspecialchars($Json['valUniversidad']),
		    'user[lc]' => htmlspecialchars($Json['valUniversidad']),
		    'commit' => 'REGISTER'
		    );

			$fields_string = "";
			foreach($fields as $key=>$value) { $fields_string .= $key.'='.urlencode($value).'&'; }
			rtrim($fields_string, '&');
			$innerHTML = "";

			$url = "https://auth.aiesec.org/users";
			$ch2 = curl_init();
			curl_setopt($ch2, CURLOPT_URL, $url);
			curl_setopt($ch2, CURLOPT_POST, count($fields));
			curl_setopt($ch2, CURLOPT_POSTFIELDS, $fields_string);

			curl_setopt($ch2, CURLOPT_RETURNTRANSFER, TRUE);
			// give cURL the SSL Cert for Salesforce
			curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false); 

			$result = curl_exec($ch2);

			//curl_errors($ch2);
			//close connection
			curl_close($ch2);
			/*libxml_use_internal_errors(true);
			$doc = new DOMDocument();
			$doc->loadHTML($result);    
			libxml_clear_errors();
			$selector = new DOMXPath($doc);

			$result = $selector->query('//div[@id="error_explanation"]');
			/*if $children = $result->item(0)->childNodes;
			
			(is_iterable($children))
			{
			    foreach ($children as $child) {
			        $tmp_doc = new DOMDocument();
			        $tmp_doc->appendChild($tmp_doc->importNode($child,true));  
			        $innerHTML .= strip_tags($tmp_doc->saveHTML());
			        //$innerHTML.add($tmp_doc->saveHTML());
			    }
			}

			$innerHTML = preg_replace('~[\r\n]+~', '', $innerHTML);
			$innerHTML = str_replace(array('"', "'"), '', $innerHTML);*/

		    //echo json_encode($matches);
		    echo  json_encode($result)  ;
	    }catch (Exception $e) {
		    echo json_encode( array(
			    "result" => false,
			    "message" => $e->getMessage(),
				));
		}

	}

	public function actionUniversitiesGreece(){
		$data = file_get_contents("http://gis-api.aiesec.org/v2/lists/mcs_alignments.json");
		$arrayData=json_decode($data);
		$Greece=[];
		foreach ($arrayData as $key => $value) {
			if($value->id==1542){
				$Greece=$value;
				break;
			}
		}
		echo json_encode($Greece);
	}
}