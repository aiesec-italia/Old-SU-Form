
<?php

require('domains.php');

class VoluntarioGlobalController extends Controller
{
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	
	public function actionIndex()
	{
		$regions = Domains::getRegions();		

		// renders the view file 'protected/views/site/index.php'
		// using the default layout 'protected/views/layouts/main.php'
		$this->render('index', array(
			'regions' => $regions
		));
	}

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
		if($error=Yii::app()->errorHandler->error)
		{
			if(Yii::app()->request->isAjaxRequest)
				echo $error['message'];
			else
				$this->render('error', $error);
		}
	}

	public function actionInserExpa(){
		try {
			$Json= $_POST['parametros'];

			$lcId = Domains::getLcId($Json['valUniversidad']);
			
			$app_id=21917709;
			$app_token="c9444a87922440229188519f8917127a";
			Yii::import("application.extensions.podio.PodioAPI", true);
			Yii::import("application.extensions.Utilidades.Comite", true);
			Podio::setup("developergreece", "79dRsK00aBKgWZDJihd9ytP9L7DkX2yyDEiNqdfjjvrr7h1lV9AMKk55VW1BKTvp");
			Podio::authenticate_with_app($app_id, $app_token);
			$Comite=new Comite();

			$fields = new PodioItemFieldCollection(array(
			  new PodioTextItemField(array("external_id" => "titulo", "values" => $Json['txtFirstName'] )),
			  new PodioTextItemField(array("external_id" => "last-name", "values" => $Json['txtLastName'])),
			  
			  new PodioTextItemField(array("external_id" => "age", "values" => $Json['txtAge'])),
			  new PodioTextItemField(array("external_id" => "telephone",  "values" => $Json['txtPhone'])),
			   
			  new PodioCategoryItemField(array("external_id" => "email", "values" => $Json['txtmail'])),
			  new PodioCategoryItemField(array("external_id" => "iduniversity", "values" => (string)$lcId)),
			  new PodioCategoryItemField(array("external_id" => "university-city", "values" => $Json['nombreUniversidad'])),
			  new PodioCategoryItemField(array("external_id" => "department", "values" => $Json['valRegion'] . ' - '. $Json['valCity'])),
			  new PodioCategoryItemField(array("external_id" => "lc", "values" => $Comite->getValorPodio((int) $lcId))),
			  new PodioCategoryItemField(array("external_id" => "how-did-you-hear-about-aiesec-2", "values" => (int) $Json['lstConocioOrganizacion']))
			));

			$item = new PodioItem(array(
			  'app' => new PodioApp($app_id), 
			  'fields' => $fields
			  ));

			// Save the new item
			$item->save();
			$countryId=1542;

			$ch = curl_init( 'https://auth.aiesec.org/users.json' );
			# Setup request to send json via POST.
			$payload = json_encode(array(
				"user"=> array(
					"first_name" => htmlspecialchars($Json['txtFirstName']),
					"last_name" => htmlspecialchars($Json['txtLastName']),
					"email" => htmlspecialchars($Json['txtmail']),
					"country_code" => '+39',
					"phone" => htmlspecialchars($Json['txtPhone']),
					"password" => htmlspecialchars($Json['txtPassword']),
					"lc" => $lcId,
					"mc" => $countryId,
					"allow_phone_communication" => "true",
					"allow_email_communication" => "true",
					"created_via" => "json"
				)
			));
			curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			# Return response instead of printing.
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			# Send request.
			$result = curl_exec($ch);
			curl_close($ch);
		

		    //echo json_encode($matches);
			echo  json_encode($result);
		}catch (Exception $e) {
			var_dump($e);
			echo json_encode( array(
				"result" => false,
				"message" => $e->getMessage(),
			));
		}

	}

	public function actionUniversitiesGreece(){		

		$data = file_get_contents("http://gis-api.aiesec.org/v2/lists/mcs_alignments.json");
		$arrayData=json_decode($data);
		$Greece=[];
		foreach ($arrayData as $key => $value) {
			if($value->id==1542){
				$Greece=$value;
				break;
			}
		}
		echo json_encode($Greece);
	}

	public function actionCities(){
		if(empty($_POST['parametros']) || empty($_POST['parametros']['region'])){
			echo '{"error":true}';
			return;
		}		

		$cities = Domains::getCitiesByRegion($_POST['parametros']['region']);
		
		echo json_encode($cities);
	}

	public function actionUniversities(){
		if(empty($_POST['parametros']) || empty($_POST['parametros']['region']) || empty($_POST['parametros']['city']) ){
			echo '{"error":true}';
			return;
		}

		$universities = Domains::getUniversities($_POST['parametros']['region'], $_POST['parametros']['city']);
		
		echo json_encode(array_values($universities));
	}


}